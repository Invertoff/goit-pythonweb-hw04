from flask import Flask, render_template, request, redirect, url_for
import socket
import json
from datetime import datetime
import os
from threading import Thread

if not os.path.exists('storage'):
    os.makedirs('storage')

if not os.path.exists('storage/data.json'):
    with open('storage/data.json', 'w') as f:
        json.dump({}, f)

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/message', methods=['GET', 'POST'])
def message():
    if request.method == 'POST':
        username = request.form['username']
        message = request.form['message']
        if username and message:
            send_message(username, message)
            return redirect(url_for('index'))
        else:
            return render_template('message.html', error="Please fill in all fields")
    return render_template('message.html')



@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html'), 404


def send_message(username, message):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_address = ('localhost', 5000)
    message_dict = {
        'username': username,
        'message': message
    }
    sock.sendto(json.dumps(message_dict).encode('utf-8'), server_address)
    sock.close()


def run_socket_server():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('localhost', 5000))

    def save_message(data):
        with open('storage/data.json', 'r+') as f:
            messages = json.load(f)
            messages[str(datetime.now())] = data
            f.seek(0)
            json.dump(messages, f, indent=4)

    while True:
        try:
            data, addr = sock.recvfrom(1024)
            message_dict = json.loads(data.decode('utf-8'))
            save_message(message_dict)
            print(f"Message received and saved: {message_dict}")
        except Exception as e:
            print(f"Error on socket server: {e}")


def run_flask():
    app.run(port=3000)

if __name__ == '__main__':
    flask_thread = Thread(target=run_flask)
    socket_thread = Thread(target=run_socket_server)

    flask_thread.start()
    socket_thread.start()

    flask_thread.join()
    socket_thread.join()
